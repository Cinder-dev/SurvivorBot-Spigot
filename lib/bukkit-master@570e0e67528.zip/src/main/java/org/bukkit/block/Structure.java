package org.bukkit.block;

public interface Structure extends BlockState {}
