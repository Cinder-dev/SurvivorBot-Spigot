package org.bukkit.entity;

public interface Shulker extends Golem {}
