package org.bukkit.entity;

/**
 * Represents a Spider.
 */
public interface Spider extends Monster {}
